
DROP INDEX idx_health_profiles_user_id;
DROP TABLE health_profiles;
